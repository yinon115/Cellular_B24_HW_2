# Battle Of The G.O.A.T's

In this game, you choose to play with basketball legend Kobe Bryant or Michael Jordan.
The purpose of the game is to prevent the other player from blocking you.

Google Drive link for video of the game:
https://drive.google.com/drive/folders/1iBCszPd-XlNKQcuGIV5qQJ6wGnSels63?usp=sharing

package com.example.obstacleracegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class ActivityGame_MJ extends AppCompatActivity {
    AppCompatImageView game_IMG_background;
    private FloatingActionButton game_FAB_left;
    private FloatingActionButton game_FAB_right;
    private MaterialButton game_BTN_goBack;
    public int score = 0;

    private ShapeableImageView[] game_IMG_hearts;
    private ShapeableImageView[][] game_IMG_obstacle;
    private ShapeableImageView[][] game_IMG_gifts;
    private ShapeableImageView[] game_IMG_player;
    private Random r;
    private int playerLocation;
    private int life;
    Timer timer = new Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_mj);

        findViews();
        initBackground();
        r = new Random();
        playerLocation = 2;
        life = 3;

        refreshUI();
        checkIfPlayerMove();

        game_BTN_goBack.setOnClickListener(view -> finish()); // Close the current activity and go back to the previous one
    }

    private void refreshUI() {
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    checkIfCollision();
                    updateHeartsUi();
                    moveObstaclesMatrixDown();
                    moveGiftsMatrixDown();
                });
            }
        }, 2000, 1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }

    @Override
    protected void onStop() {
        super.onStop();
        timer.cancel();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        refreshUI();
    }

    private void checkIfCollision() {
        // Checking collision with obstacles
        if (game_IMG_obstacle[5][playerLocation].getVisibility() == View.VISIBLE) {
            if (life > 1) {
                life--;
                Toast.makeText(this, "You Lost 1 Life", Toast.LENGTH_SHORT).show();
            } else if (life == 1) {
                Toast.makeText(this, "Game Over", Toast.LENGTH_SHORT).show();
                goToGameOverPage();
//                restartLives();
//                Toast.makeText(this, "Life's Full", Toast.LENGTH_SHORT).show();
            }
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        }

        // Checking collision with gifts
        if (game_IMG_gifts[5][playerLocation].getVisibility() == View.VISIBLE) {
            Toast.makeText(this, "You Earned 100 Points", Toast.LENGTH_SHORT).show();
            score = score + 100;
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        }


    }


    private void goToGameOverPage() {
        Intent intent = new Intent(ActivityGame_MJ.this, ActivityGame_GameOver.class);
        intent.putExtra("finalScore", score);  // Pass the final score to the new activity
        startActivity(intent);
        finish();  // Optionally finish the current activity
    }


    private void moveObstaclesMatrixDown() {
        for (int j = 0; j < 5; j++) {
            for (int i = 5; i > 0; i--) {
                game_IMG_obstacle[i][j].setVisibility(game_IMG_obstacle[i - 1][j].getVisibility());
            }
        }
        for (int i = 0; i < 5; i++) {
            game_IMG_obstacle[0][i].setVisibility(View.INVISIBLE);
        }
        int newPosition = r.nextInt(5);
        game_IMG_obstacle[0][newPosition].setVisibility(View.VISIBLE);
        checkGiftPlacement(newPosition);
    }

    private void moveGiftsMatrixDown() {
        for (int j = 0; j < 5; j++) {
            for (int i = 5; i > 0; i--) {
                game_IMG_gifts[i][j].setVisibility(game_IMG_gifts[i - 1][j].getVisibility());
            }
        }
        for (int i = 0; i < 5; i++) {
            game_IMG_gifts[0][i].setVisibility(View.INVISIBLE);
        }
        generateNewGift();
    }

    private void checkGiftPlacement(int obstaclePosition) {
        // Check if there is a gift in the same position as the obstacle
        for (int i = 0; i < 5; i++) {
            if (game_IMG_gifts[5][i].getVisibility() == View.VISIBLE && i == obstaclePosition) {
                game_IMG_gifts[5][i].setVisibility(View.INVISIBLE);
                break;
            }
        }
    }

    private void generateNewGift() {
        int newPosition = r.nextInt(5);
        // Ensure no obstacle is at the same position
        boolean isValidPosition = true;
        if (game_IMG_obstacle[0][newPosition].getVisibility() == View.VISIBLE) {
            isValidPosition = false;
        }
        if (isValidPosition) {
            game_IMG_gifts[0][newPosition].setVisibility(View.VISIBLE);
        } else {
            generateNewGift(); // Try again if the position is invalid
        }
    }

    private void checkIfPlayerMove() {
        game_FAB_left.setOnClickListener(view -> movePlayer(true));
        game_FAB_right.setOnClickListener(view -> movePlayer(false));
    }

    private void movePlayer(boolean isLeft) {
        game_IMG_player[playerLocation].setVisibility(View.INVISIBLE);
        if (isLeft && playerLocation > 0) {
            playerLocation--;
        } else if (!isLeft && playerLocation < 4) {
            playerLocation++;
        }
        game_IMG_player[playerLocation].setVisibility(View.VISIBLE);
    }

    private void initBackground() {
        Glide
                .with(this)
                .load(R.drawable.bbal_floor)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(game_IMG_background);
    }

    private void findViews() {
        game_IMG_background = findViewById(R.id.game_IMG_background);
        game_FAB_left = findViewById(R.id.game_FAB_left);
        game_FAB_right = findViewById(R.id.game_FAB_right);
        game_BTN_goBack = findViewById(R.id.game_BTN_goBack);
        initHearts();
        initObstaclesMatrix();
        initGiftsMatrix();
        initPlayerPosition();
    }

    private void initHearts() {
        game_IMG_hearts = new ShapeableImageView[]{
                findViewById(R.id.game_IMG_heart1),
                findViewById(R.id.game_IMG_heart2),
                findViewById(R.id.game_IMG_heart3),
        };
    }

    private void initObstaclesMatrix() {
        game_IMG_obstacle = new ShapeableImageView[][]{
                {findViewById(R.id.game_IMG_kb_1), findViewById(R.id.game_IMG_kb_7), findViewById(R.id.game_IMG_kb_13), findViewById(R.id.game_IMG_kb_19), findViewById(R.id.game_IMG_kb_25)},
                {findViewById(R.id.game_IMG_kb_2), findViewById(R.id.game_IMG_kb_8), findViewById(R.id.game_IMG_kb_14), findViewById(R.id.game_IMG_kb_20), findViewById(R.id.game_IMG_kb_26)},
                {findViewById(R.id.game_IMG_kb_3), findViewById(R.id.game_IMG_kb_9), findViewById(R.id.game_IMG_kb_15), findViewById(R.id.game_IMG_kb_21), findViewById(R.id.game_IMG_kb_27)},
                {findViewById(R.id.game_IMG_kb_4), findViewById(R.id.game_IMG_kb_10), findViewById(R.id.game_IMG_kb_16), findViewById(R.id.game_IMG_kb_22), findViewById(R.id.game_IMG_kb_28)},
                {findViewById(R.id.game_IMG_kb_5), findViewById(R.id.game_IMG_kb_11), findViewById(R.id.game_IMG_kb_17), findViewById(R.id.game_IMG_kb_23), findViewById(R.id.game_IMG_kb_29)},
                {findViewById(R.id.game_IMG_kb_6), findViewById(R.id.game_IMG_kb_12), findViewById(R.id.game_IMG_kb_18), findViewById(R.id.game_IMG_kb_24), findViewById(R.id.game_IMG_kb_30)}
        };
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                game_IMG_obstacle[i][j].setVisibility(View.INVISIBLE);
            }
        }
    }

    private void initGiftsMatrix() {
        game_IMG_gifts = new ShapeableImageView[][]{
                {findViewById(R.id.game_IMG_ring_1), findViewById(R.id.game_IMG_ring_2), findViewById(R.id.game_IMG_ring_13), findViewById(R.id.game_IMG_ring_19), findViewById(R.id.game_IMG_ring_25)},
                {findViewById(R.id.game_IMG_ring_2), findViewById(R.id.game_IMG_ring_8), findViewById(R.id.game_IMG_ring_14), findViewById(R.id.game_IMG_ring_20), findViewById(R.id.game_IMG_ring_26)},
                {findViewById(R.id.game_IMG_ring_3), findViewById(R.id.game_IMG_ring_9), findViewById(R.id.game_IMG_ring_15), findViewById(R.id.game_IMG_ring_21), findViewById(R.id.game_IMG_ring_27)},
                {findViewById(R.id.game_IMG_ring_4), findViewById(R.id.game_IMG_ring_10), findViewById(R.id.game_IMG_ring_16), findViewById(R.id.game_IMG_ring_22), findViewById(R.id.game_IMG_ring_28)},
                {findViewById(R.id.game_IMG_ring_5), findViewById(R.id.game_IMG_ring_11), findViewById(R.id.game_IMG_ring_17), findViewById(R.id.game_IMG_ring_23), findViewById(R.id.game_IMG_ring_29)},
                {findViewById(R.id.game_IMG_ring_6), findViewById(R.id.game_IMG_ring_12), findViewById(R.id.game_IMG_ring_18), findViewById(R.id.game_IMG_ring_24), findViewById(R.id.game_IMG_ring_30)}
        };
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                game_IMG_gifts[i][j].setVisibility(View.INVISIBLE);
            }
        }
    }

    private void initPlayerPosition() {
        game_IMG_player = new ShapeableImageView[]{
                findViewById(R.id.game_IMG_mj_1),
                findViewById(R.id.game_IMG_mj_2),
                findViewById(R.id.game_IMG_mj_3),
                findViewById(R.id.game_IMG_mj_4),
                findViewById(R.id.game_IMG_mj_5)
        };
        game_IMG_player[0].setVisibility(View.INVISIBLE);
        game_IMG_player[1].setVisibility(View.INVISIBLE);
        game_IMG_player[3].setVisibility(View.INVISIBLE);
        game_IMG_player[4].setVisibility(View.INVISIBLE);
    }

    private void updateHeartsUi() {
        for (int i = 0; i < 3; i++) {
            if (i < life) {
                game_IMG_hearts[i].setVisibility(View.VISIBLE);
            } else {
                game_IMG_hearts[i].setVisibility(View.INVISIBLE);
            }
        }
    }

    private void restartLives() {
        life = 3;
        updateHeartsUi();
    }
}


//jgjfghfghgfghgfgfgibvbivbokb
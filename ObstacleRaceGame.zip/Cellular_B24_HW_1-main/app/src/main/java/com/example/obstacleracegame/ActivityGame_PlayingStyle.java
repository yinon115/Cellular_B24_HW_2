package com.example.obstacleracegame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class ActivityGame_PlayingStyle extends AppCompatActivity {


    private ImageButton playWithBottons;
    private ImageButton playWithTilt;
    private MaterialButton game_BTN_goBack;
    private int finalScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_style_menu);

        // Get the final score from the intent
         finalScore = getIntent().getIntExtra("finalScore", 0);


        findViews();
        initViews();
    }

    private void initViews() {


        game_BTN_goBack.setOnClickListener(view -> finish()); // Close the current activity and go back to the previous one


        playWithBottons.setOnClickListener(view -> {
            // finish();
            if(finalScore == 0){
                startActivity(new Intent(ActivityGame_PlayingStyle.this, ActivityGame_MJ.class));
            } else if (finalScore ==1) {
                startActivity(new Intent(ActivityGame_PlayingStyle.this, ActivityGame_KB.class));

            }

        });

        playWithTilt.setOnClickListener(view -> {
            //finish();
            if(finalScore == 0){
                startActivity(new Intent(ActivityGame_PlayingStyle.this, ActivityGame_MJ.class));
            } else if (finalScore ==1) {
                startActivity(new Intent(ActivityGame_PlayingStyle.this, ActivityGame_KB.class));

            }
        });


    }

    private void findViews() {
        playWithBottons = findViewById(R.id.playStyleMenu_BTN_arrowsSlow);
        playWithTilt = findViewById(R.id.playStyleMenu_BTN_tilt);
        game_BTN_goBack = findViewById(R.id.playStyleMenu_BTN_goBack);

    }




























//    AppCompatImageView game_IMG_background;
//    private ImageButton playStyleMenu_BTN_arrows;
//    private ImageButton playStyleMenu_BTN_tilt;
//
//    private MaterialButton playStyleMenu_BTN_goBack;
//
//    Timer timer = new Timer();
//    //GameManager gameManager;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.play_style_menu);
//
//        findViews();
//        initBackground();
//        refreshUI();
//        goBack();
//
//
//
//    }
//
//    private void refreshUI() {
//        timer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//
//                    }
//                });
//            }
//        }, 2000, 1000);
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        timer.cancel();
//    }
//    @Override
//    protected void onStop() {
//        super.onStop();
//        timer.cancel();
//    }
//
//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        refreshUI();
//    }
//
////    private void initViews() {
////
////
////
////
////
////        playStyleMenu_BTN_arrows.setOnClickListener(view -> {
////            // finish();
////
////            ////////////////////////////////////////////////////////////////////////////
////            ///// צריך מפה לקרוא למטודה שתתחיל את המשחק לפי  בחירת צורת המשחק שנלחצה
////            /////////////////////////////////////////////////////////////////////////////
////
////            startActivity(new Intent(StartMenu.this, ActivityGame_MJ.class));
////
////        });
////
////        playStyleMenu_BTN_tilt.setOnClickListener(view -> {
////            //finish();
////
////            ////////////////////////////////////////////////////////////////////////////
////            ///// צריך מפה לקרוא למטודה שתתחיל את המשחק לפי  בחירת צורת המשחק שנלחצה
////            /////////////////////////////////////////////////////////////////////////////
////
////
////
////            startActivity(new Intent(StartMenu.this, ActivityGame_KB.class));
////
////        });
////
////    }
//
//
//
//    private void goBack(){
//
//        playStyleMenu_BTN_goBack.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                finish(); // Close the current activity and go back to the previous one
//            }
//        });
//
//
//    }
//
//    private void initBackground() {
//        Glide
//                .with(this)
//                .load(R.drawable.bbal_floor)
//                .centerCrop()
//                .placeholder(R.drawable.ic_launcher_foreground)
//                .into(game_IMG_background);
//    }
//    private void findViews() {
//        game_IMG_background = findViewById(R.id.game_IMG_background);
//        playStyleMenu_BTN_arrows = findViewById(R.id.playStyleMenu_BTN_arrows);
//        playStyleMenu_BTN_tilt = findViewById(R.id.playStyleMenu_BTN_tilt);
//        playStyleMenu_BTN_goBack = findViewById(R.id.playStyleMenu_BTN_goBack);
//
//    }
//
//
//

}

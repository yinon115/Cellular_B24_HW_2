package com.example.obstacleracegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;

public class ActivityGame_GameOver extends AppCompatActivity {

    private AppCompatImageView gameOver_IMG_background;
    private MaterialButton gameOver_BTN_goBack;
    private TextView gameOver_LBL_result;
    private EditText gameOver_EDT_name;
    private MaterialButton gameOver_BTN_saveRecord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);  // Ensure this matches the XML layout file name

        findViews();
        initBackground();

        // Get the final score from the intent
        int finalScore = getIntent().getIntExtra("finalScore", 0);
        gameOver_LBL_result.setText(String.valueOf(finalScore));

        gameOver_BTN_goBack.setOnClickListener(view -> {
            Intent intent = new Intent(ActivityGame_GameOver.this, StartMenu.class);
            startActivity(intent);
            finish();  // Close the Game Over activity
        });

        gameOver_BTN_saveRecord.setOnClickListener(view -> {
            String playerName = gameOver_EDT_name.getText().toString();
            if (playerName.isEmpty()) {
                gameOver_EDT_name.setError("Name cannot be empty");
                return;
            }

            // Save the score and player name logic here

            // Example of saving the score (to be implemented)
            // saveScoreToDatabase(playerName, finalScore);

            // After saving, navigate back to the main activity or show a success message
            Intent intent = new Intent(ActivityGame_GameOver.this, StartMenu.class);
            startActivity(intent);
            finish();  // Close the Game Over activity
        });
    }

    private void findViews() {
        gameOver_IMG_background = findViewById(R.id.gameOver_IMG_background);
        gameOver_LBL_result = findViewById(R.id.gameOver_LBL_result);
        gameOver_EDT_name = findViewById(R.id.gameOver_EDT_name);  // Updated to correct ID
        gameOver_BTN_goBack = findViewById(R.id.gameOver_BTN_goBack);
        gameOver_BTN_saveRecord = findViewById(R.id.gameOver_BTN_saveRecord);
    }

    private void initBackground() {
        Glide
                .with(this)
                .load(R.drawable.game_over)  // Ensure this drawable exists
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(gameOver_IMG_background);
    }
}

package com.example.obstacleracegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.button.MaterialButton;

import java.util.Random;


public class ActivityGame_Top10 extends AppCompatActivity{

    private AppCompatImageView top10_IMG_background;
    private MaterialButton top10_BTN_goBack;

   // private ScoresFragment fragmentScore;
    private MapsFragment fragmentMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.top_10);

        findViews();
        initBackground();

        fragmentMap= new MapsFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.top10_FRM_map, fragmentMap).commit();

        top10_BTN_goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Close the current activity and go back to the previous one
            }
        });

    }

    CallBack_List callBack_list = new CallBack_List() {
        @Override
        public void zoom(double lat, double lon) {
            GoogleMap gm = fragmentMap.getmMap();
            LatLng point = new LatLng(lon, lat);
            gm.addMarker(new MarkerOptions()
                    .position(point)
                    .title("    " ));
            gm.moveCamera(CameraUpdateFactory.newLatLngZoom(point, 13.0f));        }
    };


    private void findViews() {
        top10_IMG_background = findViewById(R.id.top10_IMG_background);
        top10_BTN_goBack = findViewById(R.id.top10_BTN_goBack);
    }

    private void initBackground() {
        Glide
                .with(this)
                .load(R.drawable.nba_trophie)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(top10_IMG_background);
    }



}

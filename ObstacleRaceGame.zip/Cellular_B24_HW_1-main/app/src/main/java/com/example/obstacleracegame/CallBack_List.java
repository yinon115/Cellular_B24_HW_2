package com.example.obstacleracegame;

public interface CallBack_List {
    void zoom(double lat, double lon);

}
